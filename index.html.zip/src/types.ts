/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export type ProductCategory = 'vegetables' | 'fruits' | 'greens' | 'dairy_pantry';

export interface Product {
  id: string;
  name: string;
  category: ProductCategory;
  price: number;
  weight: number; // in grams or kg, e.g. 500 for 500g
  unit: string;
  image: string;
  calories: number;
  origin: string;
}

export type BoxSize = 'S' | 'M' | 'L';

export interface BoxSizeDetails {
  size: BoxSize;
  name: string;
  price: number; // Base price
  maxWeight: number; // in kg
  description: string;
}

export interface PreconfiguredBox {
  id: string;
  name: string;
  description: string;
  price: number;
  weight: string;
  image: string;
  tags: string[];
  items: string[];
}

export interface CartItem {
  id: string; // unique item instance id in cart
  title: string;
  type: 'custom_box' | 'preconfigured_box';
  price: number;
  quantity: number;
  image: string;
  details?: string; // listing of items added
}

export interface Feedback {
  id: string;
  name: string;
  city: string;
  rating: number;
  text: string;
  date: string;
}
