/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useMemo, useEffect } from 'react';
import { 
  motion, 
  AnimatePresence 
} from 'motion/react';
import { 
  Sprout, 
  ShoppingBag, 
  Plus, 
  Minus, 
  Trash2, 
  X, 
  Star, 
  Check, 
  ArrowRight, 
  TrendingDown, 
  ShieldCheck, 
  Truck, 
  HelpCircle, 
  Gift, 
  Sparkles,
  ChevronDown,
  ChevronUp,
  MapPin,
  Clock,
  Phone
} from 'lucide-react';

import { PRODUCTS, BOX_SIZES, PRECONFIGURED_BOXES, FEEDBACKS, HERO_IMAGE_PATH } from './data';
import { Product, BoxSize, CartItem, Feedback } from './types';

export default function App() {
  // Shopping Cart state
  const [cart, setCart] = useState<CartItem[]>([]);
  const [isOpenCart, setIsOpenCart] = useState(false);
  const [promoCodeInput, setPromoCodeInput] = useState('');
  const [appliedDiscount, setAppliedDiscount] = useState<number | null>(null); // discount percentage
  const [promoError, setPromoError] = useState('');
  const [promoSuccess, setPromoSuccess] = useState('');

  // Customizer state
  const [selectedSize, setSelectedSize] = useState<BoxSize>('M');
  const [selectedCategory, setSelectedCategory] = useState<'vegetables' | 'greens' | 'fruits' | 'dairy_pantry'>('vegetables');
  const [customizedQuantities, setCustomizedQuantities] = useState<Record<string, number>>({});

  // Checkout modal state
  const [isOpenCheckout, setIsOpenCheckout] = useState(false);
  const [customerName, setCustomerName] = useState('');
  const [customerPhone, setCustomerPhone] = useState('');
  const [customerAddress, setCustomerAddress] = useState('');
  const [deliveryTime, setDeliveryTime] = useState('today_evening');
  const [note, setNote] = useState('');
  const [isSubmittingOrder, setIsSubmittingOrder] = useState(false);
  const [checkoutSuccessData, setCheckoutSuccessData] = useState<{
    orderId: string;
    items: CartItem[];
    total: number;
    address: string;
    deliveryTimeText: string;
  } | null>(null);

  // Active status step in order simulator
  const [activeSimulatorStep, setActiveSimulatorStep] = useState(0);

  // FAQ accordion state
  const [openFaqIndex, setOpenFaqIndex] = useState<number | null>(0);

  // Quick notification banner state
  const [showPromoBanner, setShowPromoBanner] = useState(true);

  // Highlight cart button state on addition
  const [isCartBumping, setIsCartBumping] = useState(false);

  // Feedback filter state
  const [ratingFilter, setRatingFilter] = useState<number | "all">("all");

  // Customizer calculations
  const selectedSizeInfo = useMemo(() => {
    return BOX_SIZES.find(b => b.size === selectedSize) || BOX_SIZES[1];
  }, [selectedSize]);

  // Total weight currently inside the custom box
  const customizedBoxWeight = useMemo(() => {
    let totalWeight = 0;
    Object.entries(customizedQuantities).forEach(([prodId, qty]) => {
      if (qty <= 0) return;
      const product = PRODUCTS.find(p => p.id === prodId);
      if (product) {
        // Product weight in data is in grams, we convert to kg for final sum
        totalWeight += (product.weight * qty) / 1000;
      }
    });
    return parseFloat(totalWeight.toFixed(2));
  }, [customizedQuantities]);

  // Is custom box overfilled?
  const isCustomBoxOverfilled = useMemo(() => {
    return customizedBoxWeight > selectedSizeInfo.maxWeight;
  }, [customizedBoxWeight, selectedSizeInfo]);

  // Calculate customized ingredients cost
  const customizedContentsPrice = useMemo(() => {
    let price = 0;
    Object.entries(customizedQuantities).forEach(([prodId, qty]) => {
      if (qty <= 0) return;
      const product = PRODUCTS.find(p => p.id === prodId);
      if (product) {
        price += product.price * qty;
      }
    });
    return price;
  }, [customizedQuantities]);

  const customizedBoxTotalPrice = useMemo(() => {
    return selectedSizeInfo.price + customizedContentsPrice;
  }, [selectedSizeInfo, customizedContentsPrice]);

  // Cart totals
  const cartSubtotal = useMemo(() => {
    return cart.reduce((sum, item) => sum + item.price * item.quantity, 0);
  }, [cart]);

  const cartShippingCost = useMemo(() => {
    if (cartSubtotal === 0) return 0;
    return cartSubtotal >= 2500 ? 0 : 350;
  }, [cartSubtotal]);

  const discountAmount = useMemo(() => {
    if (!appliedDiscount) return 0;
    return Math.round((cartSubtotal * appliedDiscount) / 100);
  }, [cartSubtotal, appliedDiscount]);

  const cartTotal = useMemo(() => {
    return cartSubtotal - discountAmount + cartShippingCost;
  }, [cartSubtotal, discountAmount, cartShippingCost]);

  const totalCartItemsCount = useMemo(() => {
    return cart.reduce((sum, item) => sum + item.quantity, 0);
  }, [cart]);

  // Auto-scrolling to section helpers
  const scrollToId = (id: string) => {
    const el = document.getElementById(id);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  // Bump cart animation triggers
  const triggerCartBump = () => {
    setIsCartBumping(true);
    setTimeout(() => setIsCartBumping(false), 300);
  };

  // Add customized box to cart handler
  const handleAddCustomBoxToCart = () => {
    if (isCustomBoxOverfilled) {
      alert('Ваша коробка переполнена! Уберите лишние продукты или увеличьте размер коробки.');
      return;
    }

    const itemsSummary = Object.entries(customizedQuantities)
      .filter(([_, qty]) => qty > 0)
      .map(([id, qty]) => {
        const prod = PRODUCTS.find(p => p.id === id);
        return prod ? `${prod.name} x${qty}` : '';
      })
      .filter(Boolean)
      .join(', ');

    if (!itemsSummary) {
      alert('Укажите хотя бы один фермерский продукт для наполнения коробки!');
      return;
    }

    const newItem: CartItem = {
      id: `custom-${Date.now()}`,
      title: `Индивидуальный BioBox (${selectedSize})`,
      type: 'custom_box',
      price: customizedBoxTotalPrice,
      quantity: 1,
      image: HERO_IMAGE_PATH,
      details: itemsSummary
    };

    setCart(prev => [...prev, newItem]);
    triggerCartBump();
    setIsOpenCart(true);

    // Reset quantities after adding
    setCustomizedQuantities({});
  };

  // Add preconfigured box to cart handler
  const handleAddPreconfiguredBox = (boxId: string, name: string, price: number, image: string) => {
    const targetBox = PRECONFIGURED_BOXES.find(b => b.id === boxId);
    const details = targetBox ? `Инкубатор состава: ${targetBox.items.join(', ')}` : '';

    setCart(prev => {
      // Check if already in cart
      const existingIdx = prev.findIndex(item => item.id === boxId);
      if (existingIdx > -1) {
        const updated = [...prev];
        updated[existingIdx] = {
          ...updated[existingIdx],
          quantity: updated[existingIdx].quantity + 1
        };
        return updated;
      }
      
      return [...prev, {
        id: boxId,
        title: name,
        type: 'preconfigured_box',
        price,
        quantity: 1,
        image,
        details
      }];
    });

    triggerCartBump();
    setIsOpenCart(true);
  };

  // Quick edit cart item quantity
  const updateCartItemQty = (id: string, delta: number) => {
    setCart(prev => {
      return prev.map(item => {
        if (item.id === id) {
          const newQty = item.quantity + delta;
          return newQty > 0 ? { ...item, quantity: newQty } : item;
        }
        return item;
      }).filter(item => item.quantity > 0);
    });
  };

  const removeCartItem = (id: string) => {
    setCart(prev => prev.filter(item => item.id !== id));
  };

  // Promo code validation
  const handleApplyPromo = () => {
    const code = promoCodeInput.trim().toUpperCase();
    if (code === 'BIO2026' || code === 'ORGANIC') {
      setAppliedDiscount(10);
      setPromoSuccess('Промокод применен! Скидка 10% на фермерские продукты');
      setPromoError('');
    } else {
      setPromoError('Неверный промокод. Попробуйте BIO2026');
      setPromoSuccess('');
    }
  };

  // Handle Order Submit
  const handleOrderSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customerName || !customerPhone || !customerAddress) {
      alert('Пожалуйста, заполните основные поля: имя, телефон и адрес доставки.');
      return;
    }

    setIsSubmittingOrder(true);

    // Simulate server request delay
    setTimeout(() => {
      const deliveryTimesMap: Record<string, string> = {
        'today_evening': 'Сегодня, 18:00 — 19:30',
        'tomorrow_morning': 'Завтра, 09:00 — 11:00',
        'tomorrow_day': 'Завтра, 14:00 — 16:00',
        'weekly_sub': 'Регулярно по вторникам, 10:00'
      };

      setCheckoutSuccessData({
        orderId: `BIO-${Math.floor(100000 + Math.random() * 900000)}`,
        items: [...cart],
        total: cartTotal,
        address: customerAddress,
        deliveryTimeText: deliveryTimesMap[deliveryTime] || 'В выбранное время'
      });

      setIsSubmittingOrder(false);
      setCart([]); // Clear cart
      setAppliedDiscount(null);
      setPromoCodeInput('');
      setPromoSuccess('');
    }, 1500);
  };

  // Simulate active progress step in order visualizer after success checkout
  useEffect(() => {
    if (!checkoutSuccessData) {
      setActiveSimulatorStep(0);
      return;
    }

    const interval = setInterval(() => {
      setActiveSimulatorStep(prev => {
        if (prev < 3) return prev + 1;
        return prev;
      });
    }, 4500);

    return () => clearInterval(interval);
  }, [checkoutSuccessData]);

  // Customizer increment/decrement helper
  const handleCustomizerQtyChange = (prodId: string, delta: number) => {
    setCustomizedQuantities(prev => {
      const current = prev[prodId] || 0;
      const next = current + delta;
      return {
        ...prev,
        [prodId]: next >= 0 ? next : 0
      };
    });
  };

  // Filter feedbacks
  const filteredFeedbacks = useMemo(() => {
    if (ratingFilter === 'all') return FEEDBACKS;
    return FEEDBACKS.filter(f => f.rating === ratingFilter);
  }, [ratingFilter]);

  // Dynamic ecological stats for customized box
  const customEcoStats = useMemo(() => {
    // Supposing 1 unit of product saves roughly 30g plastic and 0.8kg CO2-equivalent compared to traditional retail chain loops
    let totalItems = 0;
    Object.values(customizedQuantities).forEach(qty => {
      totalItems += qty;
    });

    return {
      plasticSavedGrams: totalItems * 35,
      co2ReducedKg: parseFloat((totalItems * 0.9 + (selectedSize === 'S' ? 1.2 : selectedSize === 'M' ? 2.1 : 3.5)).toFixed(1)),
      localSupportPercent: 74
    };
  }, [customizedQuantities, selectedSize]);

  return (
    <div className="min-h-screen selection:bg-brand-sage-light selection:text-white font-sans text-brand-charcoal bg-brand-beige overflow-hidden">
      
      {/* Top micro promo bar */}
      {showPromoBanner && (
        <div id="promobar" className="bg-brand-sage text-brand-cream text-xs py-2 px-4 flex justify-between items-center relative z-40 font-mono tracking-wider">
          <div className="flex items-center gap-2 mx-auto text-center">
            <Sparkles className="w-3.5 h-3.5 text-brand-sand animate-pulse" />
            <span>ПЕРВЫЙ ЗАКАЗ? ПРИМЕНИТЕ ПРОМОКОД <strong className="underline decoration-brand-sand text-white decoration-2">BIO2026</strong> НА СКИДКУ 10%</span>
          </div>
          <button 
            id="close-banner"
            onClick={() => setShowPromoBanner(false)}
            className="absolute right-4 hover:text-brand-sand transition"
            aria-label="Закрыть"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {/* Primary Minimalist Header */}
      <header className="sticky top-0 z-30 bg-brand-beige/95 backdrop-blur-md border-b border-brand-sand/40 py-4 px-4 sm:px-8 transition-all">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          
          {/* Logo Brandmark */}
          <div 
            onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })} 
            className="flex items-center gap-2 cursor-pointer group"
          >
            <div className="w-9 h-9 rounded-full bg-brand-sage flex items-center justify-center text-brand-cream transition-transform group-hover:rotate-12 duration-500">
              <Sprout className="w-5 h-5" />
            </div>
            <div>
              <span className="font-serif text-lg font-bold tracking-tight text-neutral-900 group-hover:text-brand-sage transition-colors">Organic Box</span>
              <span className="block text-[10px] font-mono tracking-widest text-brand-sage-light uppercase -mt-1">Честная земля</span>
            </div>
          </div>

          {/* Nav Links */}
          <nav className="hidden md:flex items-center gap-8 text-sm font-medium tracking-wide">
            <button onClick={() => scrollToId('benefits')} className="text-brand-charcoal hover:text-brand-sage transition-colors">Философия</button>
            <button onClick={() => scrollToId('preconfigured')} className="text-brand-charcoal hover:text-brand-sage transition-colors">Готовые наборы</button>
            <button onClick={() => scrollToId('customizer')} className="text-brand-charcoal hover:text-brand-sage transition-colors bg-brand-sage-ultra px-3 py-1.5 rounded-full text-brand-sage font-semibold">Собрать BioBox</button>
            <button onClick={() => scrollToId('reviews')} className="text-brand-charcoal hover:text-brand-sage transition-colors">Отзывы</button>
            <button onClick={() => scrollToId('faq')} className="text-brand-charcoal hover:text-brand-sage transition-colors">Вопросы</button>
          </nav>

          {/* Action buttons & shopping cart status */}
          <div className="flex items-center gap-3">
            <button 
              id="header-customizer-btn"
              onClick={() => scrollToId('customizer')}
              className="hidden sm:inline-flex text-xs font-semibold uppercase tracking-widest bg-transparent border border-brand-charcoal hover:bg-brand-charcoal hover:text-white transition-all py-2 px-4 rounded-none"
            >
              Конструктор коробки
            </button>

            <button
              id="cart-trigger"
              onClick={() => setIsOpenCart(true)}
              className={`relative px-4 py-2.5 bg-brand-sage text-brand-cream hover:bg-[#344231] transition-all rounded-full flex items-center gap-2 font-mono text-sm ${
                isCartBumping ? 'scale-110 shadow-lg' : ''
              }`}
            >
              <ShoppingBag className="w-4 h-4" />
              <span className="hidden sm:inline">Корзина</span>
              <AnimatePresence mode="wait">
                {totalCartItemsCount > 0 && (
                  <motion.span 
                    key={totalCartItemsCount}
                    initial={{ scale: 0.6, opacity: 0 }}
                    animate={{ scale: 1, opacity: 1 }}
                    exit={{ scale: 0.6, opacity: 0 }}
                    className="w-5 h-5 bg-brand-accent text-white rounded-full flex items-center justify-center text-[10px] font-bold"
                  >
                    {totalCartItemsCount}
                  </motion.span>
                )}
              </AnimatePresence>
            </button>
          </div>

        </div>
      </header>

      {/* Hero Section */}
      <section id="hero" className="relative pt-8 pb-16 md:py-24 px-4 sm:px-8 overflow-hidden bg-brand-cream border-b border-brand-sand/40">
        <div className="absolute right-0 top-0 w-1/3 h-full bg-brand-beige/30 pointer-events-none rounded-l-[120px]" />
        
        <div className="max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-12 gap-12 items-center relative z-10">
          
          {/* Typography Content */}
          <div className="lg:col-span-7 flex flex-col items-start">
            <div className="inline-flex items-center gap-2 px-3 py-1 bg-brand-sage-ultra rounded-full text-brand-sage font-mono text-xs tracking-wider mb-6">
              <span className="w-2 h-2 rounded-full bg-brand-sage-light animate-ping" />
              <span>ФЕРМЕРСКИЙ СЕЗОН 2026 ОТКРЫТ</span>
            </div>

            <h1 className="font-serif text-4xl sm:text-6xl lg:text-7xl font-light tracking-tight text-neutral-900 leading-[1.08] mb-6">
              Чистая земля.<br />
              <span className="font-serif italic text-brand-accent">Честная еда.</span>
            </h1>

            <p className="text-md sm:text-lg text-brand-charcoal/80 max-w-xl leading-relaxed mb-8 font-light">
              Собранные на рассвете органические овощи, дикие ягоды, ремесленный сыр и цельнозерновой хлеб в эко-коробах у вас на пороге за 1.5 часа. Напрямую от семейных артелей без посредников и химии.
            </p>

            {/* CTA block */}
            <div className="flex flex-col sm:flex-row gap-4 w-full sm:w-auto">
              <button
                id="hero-primary-cta"
                onClick={() => scrollToId('customizer')}
                className="w-full sm:w-auto px-8 py-4 bg-brand-sage text-brand-cream hover:bg-brand-charcoal transition-all text-sm font-semibold tracking-wider uppercase inline-flex items-center justify-center gap-2 group"
              >
                <span>Собрать свой BioBox</span>
                <ArrowRight className="w-4 h-4 group-hover:translate-x-1.5 transition-transform" />
              </button>
              
              <button
                id="hero-secondary-cta"
                onClick={() => scrollToId('preconfigured')}
                className="w-full sm:w-auto px-8 py-4 bg-transparent border border-brand-charcoal text-brand-charcoal hover:bg-brand-charcoal/5 transition-all text-sm font-semibold tracking-wider uppercase inline-flex items-center justify-center"
              >
                Выбрать готовый набор
              </button>
            </div>

            {/* Live Micro Indicators */}
            <div className="grid grid-cols-3 gap-6 mt-12 pt-10 border-t border-brand-sand/60 w-full max-w-lg font-mono">
              <div>
                <span className="block text-xl font-bold text-brand-sage">1.5 часа</span>
                <span className="text-[11px] uppercase tracking-wider text-brand-charcoal/60">Логистика</span>
              </div>
              <div>
                <span className="block text-xl font-bold text-brand-sage">100% Био</span>
                <span className="text-[11px] uppercase tracking-wider text-brand-charcoal/60">Без пестицидов</span>
              </div>
              <div>
                <span className="block text-xl font-bold text-brand-sage">26 ферм</span>
                <span className="text-[11px] uppercase tracking-wider text-brand-charcoal/60">Сотрудничество</span>
              </div>
            </div>

          </div>

          {/* Hero Image Frame with Minimal Decor */}
          <div className="lg:col-span-5 relative mt-8 lg:mt-0">
            <div className="absolute -inset-4 border border-brand-charcoal/10 rounded-3xl pointer-events-none translate-x-2 translate-y-3" />
            <div className="relative rounded-2xl overflow-hidden shadow-2xl bg-brand-sand/20 aspect-[4/3] sm:aspect-[16/11]">
              <img 
                src={HERO_IMAGE_PATH} 
                alt="Свежие органические продукты в деревянном коробе" 
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-brand-charcoal/30 via-transparent to-transparent pointer-events-none" />
              
              {/* Dynamic stamp/badge */}
              <div className="absolute bottom-4 left-4 bg-brand-cream/95 backdrop-blur-md border border-brand-sand flex items-center gap-3 px-4 py-2.5 shadow-md">
                <div className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-ping" />
                <div className="font-mono text-[11px] uppercase tracking-wider text-brand-charcoal">
                  <span>Свежий сбор: </span>
                  <strong className="text-brand-sage font-bold">Сегодня 06:15</strong>
                </div>
              </div>
            </div>
            
            {/* Visual Leaf detail */}
            <div className="absolute -top-6 -right-6 w-12 h-12 rounded-full bg-brand-cream shadow-md flex items-center justify-center border border-brand-sand text-brand-sage-light">
              <Star className="w-5 h-5 fill-brand-sand text-brand-sand" />
            </div>
          </div>

        </div>
      </section>

      {/* Environmental Values Section */}
      <section id="benefits" className="py-20 px-4 sm:px-8 border-b border-brand-sand/40 bg-brand-beige">
        <div className="max-w-7xl mx-auto">
          
          <div className="text-center max-w-2xl mx-auto mb-16">
            <span className="font-mono text-xs uppercase tracking-widest text-brand-sage-light font-bold block mb-3">наша философия</span>
            <h2 className="font-serif text-3xl sm:text-5xl font-light tracking-tight mb-5">Честные обещания — настоящая забота</h2>
            <p className="text-brand-charcoal/70 text-sm sm:text-base font-light">Доставка еды должна оздоравливать не только человека, но и почву, на которой выросли продукты.</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            
            {/* Card 1 */}
            <div className="p-8 bg-brand-cream border border-brand-sand/40 hover:border-brand-sage-light/60 transition-all rounded-sm flex flex-col justify-between">
              <div>
                <div className="w-10 h-10 rounded-full bg-brand-sage-ultra flex items-center justify-center text-brand-sage mb-6">
                  <ShieldCheck className="w-5 h-5" />
                </div>
                <h3 className="font-serif text-lg font-medium text-neutral-950 mb-3">Чистый био-контроль</h3>
                <p className="text-xs sm:text-sm text-brand-charcoal/70 font-light leading-relaxed">
                  Постоянные лабораторные пробы каждой партии урожая на нитраты, тяжелые металлы и антибиотики. Полное отсутствие ГМО и гормонов роста.
                </p>
              </div>
              <div className="mt-6 pt-4 border-t border-brand-sand/30 font-mono text-[10px] text-brand-sage uppercase font-bold tracking-wider flex items-center gap-1.5">
                <span>0% пестицидов</span>
              </div>
            </div>

            {/* Card 2 */}
            <div className="p-8 bg-brand-cream border border-brand-sand/40 hover:border-brand-sage-light/60 transition-all rounded-sm flex flex-col justify-between">
              <div>
                <div className="w-10 h-10 rounded-full bg-brand-sage-ultra flex items-center justify-center text-brand-sage mb-6">
                  <Truck className="w-5 h-5" />
                </div>
                <h3 className="font-serif text-lg font-medium text-neutral-950 mb-3">Холодная цепь свежести</h3>
                <p className="text-xs sm:text-sm text-brand-charcoal/70 font-light leading-relaxed">
                  Мы собираем боксы при температуре +4°С и доставляем их в термо-контейнерах на экологичных охлаждаемых автомобилях в течение 120 минут.
                </p>
              </div>
              <div className="mt-6 pt-4 border-t border-brand-sand/30 font-mono text-[10px] text-brand-sage uppercase font-bold tracking-wider flex items-center gap-1.5">
                <span>замораживание исключено</span>
              </div>
            </div>

            {/* Card 3 */}
            <div className="p-8 bg-brand-cream border border-brand-sand/40 hover:border-brand-sage-light/60 transition-all rounded-sm flex flex-col justify-between">
              <div>
                <div className="w-10 h-10 rounded-full bg-brand-sage-ultra flex items-center justify-center text-brand-sage mb-6">
                  <TrendingDown className="w-5 h-5" />
                </div>
                <h3 className="font-serif text-lg font-medium text-neutral-950 mb-3">Zero Waste подход</h3>
                <p className="text-xs sm:text-sm text-brand-charcoal/70 font-light leading-relaxed">
                  Деревянные короба являются многоразовыми: при следующей доставке вы просто отдаете их курьеру. Нет одноразовой пластиковой пленки и фасовочных пакетов.
                </p>
              </div>
              <div className="mt-6 pt-4 border-t border-brand-sand/30 font-mono text-[10px] text-brand-sage uppercase font-bold tracking-wider flex items-center gap-1.5">
                <span>бумажные эко-пакеты</span>
              </div>
            </div>

            {/* Card 4 */}
            <div className="p-8 bg-brand-cream border border-brand-sand/40 hover:border-brand-sage-light/60 transition-all rounded-sm flex flex-col justify-between">
              <div>
                <div className="w-10 h-10 rounded-full bg-brand-sage-ultra flex items-center justify-center text-brand-sage mb-6">
                  <Gift className="w-5 h-5" />
                </div>
                <h3 className="font-serif text-lg font-medium text-neutral-950 mb-3">Поддержка малых ферм</h3>
                <p className="text-xs sm:text-sm text-brand-charcoal/70 font-light leading-relaxed">
                  Мы платим фермерам справедливую рыночную цену напрямую. Ваши покупки финансируют семейные подряды в Тверской, Тульской и Калужской областях.
                </p>
              </div>
              <div className="mt-6 pt-4 border-t border-brand-sand/30 font-mono text-[10px] text-brand-sage uppercase font-bold tracking-wider flex items-center gap-1.5">
                <span>70% дохода фермерам</span>
              </div>
            </div>

          </div>

        </div>
      </section>

      {/* Curated Pre-Configured Premium Boxes */}
      <section id="preconfigured" className="py-20 px-4 sm:px-8 border-b border-brand-sand/40 bg-brand-cream">
        <div className="max-w-7xl mx-auto">
          
          <div className="flex flex-col md:flex-row md:items-end justify-between mb-16">
            <div>
              <span className="font-mono text-xs uppercase tracking-widest text-brand-sage-light font-bold block mb-3">готовые решения</span>
              <h2 className="font-serif text-3xl sm:text-5xl font-light tracking-tight text-neutral-900">Каталог сезонных сборов</h2>
            </div>
            <p className="text-brand-charcoal/70 text-sm max-w-md mt-4 md:mt-0 font-light">
              Сбалансированные подборки от наших нутрициологов и шеф-поваров. Идеально подходят как для детокса, так и для семейных обедов.
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {PRECONFIGURED_BOXES.map((box) => (
              <div 
                key={box.id}
                className="bg-brand-beige overflow-hidden border border-brand-sand/60 hover:shadow-xl hover:-translate-y-1 transition-all duration-300 flex flex-col h-full rounded-md"
              >
                
                {/* Product Image Frame */}
                <div className="aspect-[4/3] w-full overflow-hidden bg-brand-sand/20 relative group">
                  <img 
                    src={box.image === 'DETOX' ? 'DETOX_IMAGE_PATH' : box.image} 
                    alt={box.name} 
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute top-4 left-4 flex flex-wrap gap-1.5 max-w-[85%]">
                    {box.tags.map((tag, i) => (
                      <span key={i} className="bg-brand-cream/90 backdrop-blur-sm border border-brand-sand/50 text-[10px] font-mono uppercase tracking-wider text-brand-charcoal py-1 px-2.5">
                        {tag}
                      </span>
                    ))}
                  </div>
                  <span className="absolute bottom-4 right-4 bg-brand-charcoal text-brand-cream text-xs font-mono px-3 py-1">
                    {box.weight}
                  </span>
                </div>

                {/* Card Content Description */}
                <div className="p-8 flex-1 flex flex-col justify-between">
                  <div>
                    <h3 className="font-serif text-2xl font-light text-neutral-950 mb-3">{box.name}</h3>
                    <p className="text-sm text-brand-charcoal/75 leading-relaxed mb-6 font-light">{box.description}</p>
                    
                    {/* Ingredients detail */}
                    <div className="mb-8">
                      <span className="block font-mono text-[10px] uppercase text-brand-charcoal/50 mb-2 tracking-wider">состав короба:</span>
                      <ul className="grid grid-cols-2 gap-y-1.5 gap-x-4">
                        {box.items.map((item, idx) => (
                          <li key={idx} className="text-xs text-brand-charcoal/80 flex items-center gap-1.5 font-light">
                            <span className="w-1 h-1 rounded-full bg-brand-sage-light flex-shrink-0" />
                            <span className="truncate">{item}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>

                  {/* Actions & pricing block */}
                  <div className="pt-6 border-t border-brand-sand/40 flex items-center justify-between">
                    <div>
                      <span className="block font-mono text-[10px] text-brand-charcoal/50 uppercase tracking-widest">СТОИМОСТЬ</span>
                      <span className="text-2xl font-serif font-medium text-brand-charcoal">{box.price.toLocaleString('ru-RU')} ₽</span>
                    </div>

                    <button
                      id={`add-preconfigured-${box.id}`}
                      onClick={() => handleAddPreconfiguredBox(box.id, box.name, box.price, box.image)}
                      className="px-6 py-3 bg-brand-sage hover:bg-brand-charcoal text-brand-cream focus:ring-2 focus:ring-brand-sage-light transition-all font-mono text-xs uppercase tracking-wider"
                    >
                      В корзину
                    </button>
                  </div>

                </div>

              </div>
            ))}
          </div>

        </div>
      </section>

      {/* Centerpiece: The Interactive BioBox Customizer (`Конструктор Коробки`) */}
      <section id="customizer" className="py-20 px-4 sm:px-8 bg-brand-beige border-b border-brand-sand/40 scroll-mt-20">
        <div className="max-w-7xl mx-auto">
          
          <div className="text-center max-w-3xl mx-auto mb-16">
            <span className="inline-block px-3 py-1 bg-brand-sage text-brand-cream font-mono text-[10px] uppercase tracking-widest rounded-full mb-3">персональный подбор</span>
            <h2 className="font-serif text-3xl sm:text-5xl font-light tracking-tight text-neutral-900 mb-5">Конструктор личного BioBox 2.0</h2>
            <p className="text-brand-charcoal/70 text-sm sm:text-base font-light leading-relaxed">
              Выберите базовый объем деревянного короба и наполните его исключительно любимыми ингредиентами. Следите за его весом и ценой прямо в режиме реального времени. Настоящий фермерский кастомайзер.
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start">
            
            {/* Left Column: Product Picker (8 cols) */}
            <div className="lg:col-span-8 space-y-8 bg-brand-cream p-6 sm:p-8 border border-brand-sand rounded-xl shadow-sm">
              
              {/* Step 1 Selector Header */}
              <div>
                <div className="flex items-center gap-3 mb-4">
                  <span className="w-6 h-6 rounded-full bg-brand-sage text-brand-cream text-xs font-mono flex items-center justify-center font-bold">1</span>
                  <h3 className="font-serif text-xl font-medium">Выберите формат короба:</h3>
                </div>
                
                {/* Size options grids */}
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                  {BOX_SIZES.map((box) => (
                    <button
                      id={`size-${box.size}`}
                      key={box.size}
                      onClick={() => setSelectedSize(box.size)}
                      className={`text-left p-5 transition-all outline-none border focus:ring-2 focus:ring-brand-sage-light relative ${
                        selectedSize === box.size 
                          ? 'bg-brand-sage-ultra border-brand-sage shadow-sm' 
                          : 'bg-brand-beige/50 hover:bg-brand-beige border-brand-sand'
                      }`}
                    >
                      <div className="flex justify-between items-start mb-2">
                        <span className="font-mono text-xs text-brand-sage uppercase font-bold tracking-widest">РАЗМЕР {box.size}</span>
                        {selectedSize === box.size && (
                          <span className="w-5 h-5 rounded-full bg-brand-sage text-brand-cream flex items-center justify-center">
                            <Check className="w-3.5 h-3.5" />
                          </span>
                        )}
                      </div>
                      <h4 className="font-serif text-md font-semibold text-neutral-900 mb-1">{box.name}</h4>
                      <p className="text-[11px] text-brand-charcoal/60 leading-tight mb-3 min-h-[32px]">{box.description}</p>
                      
                      <div className="pt-2 border-t border-brand-sand/40 flex justify-between items-end font-mono">
                        <div>
                          <span className="block text-[9px] text-brand-charcoal/40 uppercase">Лимит веса</span>
                          <span className="font-bold text-brand-charcoal text-xs">до {box.maxWeight} кг</span>
                        </div>
                        <div>
                          <span className="block text-[9px] text-brand-charcoal/40 uppercase text-right">БАЗОВАЯ ЦЕНА</span>
                          <span className="font-bold text-brand-sage text-sm">{box.price} ₽</span>
                        </div>
                      </div>
                    </button>
                  ))}
                </div>
              </div>

              {/* Step 2 Category Section Picker */}
              <div className="pt-4 border-t border-brand-sand/40">
                <div className="flex items-center gap-3 mb-6">
                  <span className="w-6 h-6 rounded-full bg-brand-sage text-brand-cream text-xs font-mono flex items-center justify-center font-bold">2</span>
                  <h3 className="font-serif text-xl font-medium">Наполните короб фермерскими био-продуктами:</h3>
                </div>

                {/* Tab category pills */}
                <div className="flex flex-wrap gap-2 border-b border-brand-sand/60 pb-3 mb-6">
                  {[
                    { id: 'vegetables', label: 'Овощи 🥕' },
                    { id: 'greens', label: 'Свежая зелень 🥬' },
                    { id: 'fruits', label: 'Ягоды и Фрукты 🍓' },
                    { id: 'dairy_pantry', label: 'Бакалея и Молоко 🥚' }
                  ].map((tab) => (
                    <button
                      id={`category-tab-${tab.id}`}
                      key={tab.id}
                      onClick={() => setSelectedCategory(tab.id as any)}
                      className={`px-4 py-2.5 text-xs font-semibold uppercase tracking-wider transition-all rounded-full border ${
                        selectedCategory === tab.id
                          ? 'bg-brand-sage text-brand-cream border-brand-sage'
                          : 'bg-transparent text-brand-charcoal border-brand-sand hover:bg-brand-beige'
                      }`}
                    >
                      {tab.label}
                    </button>
                  ))}
                </div>

                {/* Sub-product grid block */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {PRODUCTS.filter(p => p.category === selectedCategory).map((product) => {
                    const currentQty = customizedQuantities[product.id] || 0;
                    return (
                      <div 
                        id={`custom-prod-card-${product.id}`}
                        key={product.id}
                        className={`p-4 bg-brand-beige/40 border transition-all flex gap-3 ${
                          currentQty > 0 ? 'border-brand-sage-light bg-brand-sage-ultra/25' : 'border-brand-sand/60 hover:bg-brand-beige/80'
                        }`}
                      >
                        {/* Compact thumbnail image */}
                        <div className="w-20 h-20 rounded-md overflow-hidden bg-brand-sand/20 flex-shrink-0 relative">
                          <img 
                            src={product.image} 
                            alt={product.name} 
                            className="w-full h-full object-cover"
                            referrerPolicy="no-referrer"
                          />
                          {currentQty > 0 && (
                            <span className="absolute top-1 left-1 bg-brand-accent text-white font-mono text-[9px] px-1.5 py-0.5 font-bold rounded-sm z-10 animate-bounce">
                              +{currentQty}
                            </span>
                          )}
                        </div>

                        {/* Text explanation */}
                        <div className="flex-1 flex flex-col justify-between min-w-0">
                          <div>
                            <h4 className="font-serif text-sm font-semibold text-neutral-900 leading-tight truncate">{product.name}</h4>
                            <span className="block font-mono text-[9px] text-brand-charcoal/50 uppercase mt-0.5 truncate">
                              {product.origin}
                            </span>
                            <span className="inline-block mt-1 font-mono text-[10px] bg-brand-sand/50 text-brand-charcoal/80 px-2 py-0.5 uppercase tracking-wide">
                              {product.unit} ({(product.weight / 1000).toFixed(2)} кг)
                            </span>
                          </div>

                          {/* Incremention counter controller */}
                          <div className="flex items-center justify-between mt-2 pt-2 border-t border-brand-sand/20">
                            <span className="font-mono text-xs font-bold text-brand-sage">{product.price} ₽</span>
                            
                            <div className="flex items-center gap-1.5 bg-brand-cream py-1 px-1.5 border border-brand-sand/60 rounded-full">
                              <button
                                id={`dec-cust-${product.id}`}
                                onClick={() => handleCustomizerQtyChange(product.id, -1)}
                                className="w-5.5 h-5.5 hover:bg-brand-beige transition rounded-full flex items-center justify-center text-brand-charcoal"
                                aria-label="Убавить"
                                disabled={currentQty === 0}
                              >
                                <Minus className="w-3.5 h-3.5" />
                              </button>
                              <span className="w-5 text-center font-mono text-xs font-bold">{currentQty}</span>
                              <button
                                id={`inc-cust-${product.id}`}
                                onClick={() => handleCustomizerQtyChange(product.id, 1)}
                                className="w-5.5 h-5.5 hover:bg-brand-beige transition rounded-full flex items-center justify-center text-brand-charcoal"
                                aria-label="Добавить"
                              >
                                <Plus className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          </div>

                        </div>
                      </div>
                    );
                  })}
                </div>

              </div>

            </div>

            {/* Right Column: Dynamic Simulated Wood Box Visualizer (4 cols) */}
            <div className="lg:col-span-4 sticky top-28 space-y-6">
              
              {/* Box Simulator Receipt Card */}
              <div className="bg-brand-cream border border-brand-sand rounded-xl p-6 shadow-sm overflow-hidden relative">
                
                {/* Decorative simulated organic label banner */}
                <div className="absolute top-0 right-0 w-24 h-24 overflow-hidden pointer-events-none">
                  <div className="bg-brand-sage text-brand-cream text-[8px] font-mono uppercase text-center absolute top-4 right-[-28px] rotate-45 w-[110px] py-1 tracking-widest shadow-sm">
                    ORGANIC
                  </div>
                </div>

                <div className="border-b border-brand-sand/60 pb-4 mb-6">
                  <span className="font-mono text-[9px] tracking-wider text-brand-sage-light uppercase block font-bold">СОБИРАЕТСЯ СЕЙЧАС</span>
                  <h3 className="font-serif text-2xl font-light text-neutral-900">{selectedSizeInfo.name}</h3>
                </div>

                {/* Weight limit progress bar scale */}
                <div className="space-y-2 mb-6">
                  <div className="flex justify-between items-end text-xs font-mono">
                    <span className="text-brand-charcoal/60 uppercase">Загрузка короба:</span>
                    <span className={`font-bold ${isCustomBoxOverfilled ? 'text-rose-600 animate-pulse' : 'text-brand-sage'}`}>
                      {customizedBoxWeight} кг / {selectedSizeInfo.maxWeight} кг.
                    </span>
                  </div>
                  
                  {/* Progress Line */}
                  <div className="w-full h-2.5 bg-brand-beige border border-brand-sand overflow-hidden rounded-full">
                    <div 
                      className={`h-full transition-all duration-300 ${
                        isCustomBoxOverfilled ? 'bg-rose-500' : 'bg-brand-sage'
                      }`}
                      style={{ width: `${Math.min((customizedBoxWeight / selectedSizeInfo.maxWeight) * 100, 100)}%` }}
                    />
                  </div>

                  {/* Weight restriction alerts */}
                  {isCustomBoxOverfilled ? (
                    <p className="text-[11px] text-rose-600 font-mono leading-tight bg-rose-50 border border-rose-200/55 p-2 rounded-sm animate-pulse">
                      ▲ Коробка переполнена! Лимит веса размера {selectedSize} составляет {selectedSizeInfo.maxWeight} кг. Пожалуйста, уберите {parseFloat((customizedBoxWeight - selectedSizeInfo.maxWeight).toFixed(2))} кг или выберите размер больше.
                    </p>
                  ) : customizedBoxWeight === 0 ? (
                    <p className="text-[11px] text-brand-charcoal/40 font-mono italic leading-tight">
                      Коробка пуста. Выбирайте фермерские продукты слева, чтобы наполнить её сочным урожаем.
                    </p>
                  ) : (
                    <p className="text-[11px] text-brand-sage font-mono leading-tight">
                      ✓ Отлично! Осталось свободного места для {parseFloat((selectedSizeInfo.maxWeight - customizedBoxWeight).toFixed(2))} кг.
                    </p>
                  )}
                </div>

                {/* Items preview box block (simulating raw lists inside) */}
                <div className="bg-brand-beige/50 border border-brand-sand/60 p-4 rounded-lg mb-6">
                  <span className="font-mono text-[9px] uppercase tracking-wider text-brand-charcoal/50 block mb-2.5">СОДЕРЖИМОЕ КУЗОВА:</span>
                  
                  {Object.entries(customizedQuantities).filter(([_, qty]) => qty > 0).length === 0 ? (
                    <div className="py-6 text-center border border-dashed border-brand-sand rounded-md">
                      <ShoppingBag className="w-6 h-6 text-brand-sand mx-auto mb-2 opacity-60" />
                      <span className="block font-mono text-[10px] text-brand-charcoal/40 uppercase">короб пока пуст</span>
                    </div>
                  ) : (
                    <div className="max-h-56 overflow-y-auto space-y-2 pr-1">
                      {Object.entries(customizedQuantities)
                        .filter(([_, qty]) => qty > 0)
                        .map(([id, qty]) => {
                          const product = PRODUCTS.find(p => p.id === id);
                          if (!product) return null;
                          return (
                            <div key={id} className="flex justify-between items-center text-xs font-mono py-1 border-b border-brand-sand/30 last:border-0">
                              <span className="truncate max-w-[70%] font-light text-brand-charcoal/90">{product.name}</span>
                              <div className="flex items-center gap-1 bg-brand-cream/80 px-2 py-0.5 border border-brand-sand/40">
                                <span>x{qty}</span>
                                <span className="text-[9px] text-brand-charcoal/40">({(product.weight * qty / 1000).toFixed(1)}кг)</span>
                              </div>
                            </div>
                          );
                        })}
                    </div>
                  )}

                </div>

                {/* Embedded ecological impact calculator block */}
                {customizedBoxWeight > 0 && (
                  <div className="p-4 bg-brand-sage-ultra rounded-lg border border-brand-sage-light/20 space-y-3 mb-6">
                    <div className="flex items-center gap-1.5 text-brand-sage font-serif font-semibold text-sm">
                      <Sparkles className="w-4 h-4" />
                      <span>Ваш экологический след:</span>
                    </div>
                    <div className="grid grid-cols-2 gap-4 font-mono text-[11px]">
                      <div>
                        <span className="block text-brand-charcoal/40 uppercase">Пластик</span>
                        <strong className="text-brand-sage">-{customEcoStats.plasticSavedGrams} г</strong>
                      </div>
                      <div>
                        <span className="block text-brand-charcoal/40 uppercase">LOGISTICS СO₂</span>
                        <strong className="text-brand-sage">-{customEcoStats.co2ReducedKg} кг</strong>
                      </div>
                    </div>
                  </div>
                )}

                {/* Pricing Summary */}
                <div className="pt-4 border-t border-brand-sand/80 space-y-2 font-mono">
                  <div className="flex justify-between text-xs text-brand-charcoal/60">
                    <span>Базовый короб ({selectedSize}):</span>
                    <span>{selectedSizeInfo.price} ₽</span>
                  </div>
                  <div className="flex justify-between text-xs text-brand-charcoal/60">
                    <span>Локальные ингредиенты:</span>
                    <span>{customizedContentsPrice} ₽</span>
                  </div>
                  
                  <div className="flex justify-between text-base border-t border-brand-sand/60 pt-3 text-neutral-900">
                    <span className="font-serif">ИТОГО КОРОБ:</span>
                    <strong className="font-mono text-xl text-brand-sage">{customizedBoxTotalPrice} ₽</strong>
                  </div>
                </div>

                {/* Confirm box action button */}
                <button
                  id="confirm-customizer-box"
                  onClick={handleAddCustomBoxToCart}
                  disabled={isCustomBoxOverfilled || customizedBoxWeight === 0}
                  className={`w-full text-center mt-6 py-4 transition-all tracking-wider font-mono text-xs uppercase cursor-pointer relative z-10 ${
                    customizedBoxWeight === 0 
                      ? 'bg-neutral-200 text-neutral-400 cursor-not-allowed'
                      : isCustomBoxOverfilled
                      ? 'bg-rose-50 text-rose-500 border border-rose-300 cursor-not-allowed'
                      : 'bg-brand-sage text-brand-cream hover:bg-brand-charcoal'
                  }`}
                >
                  {isCustomBoxOverfilled 
                    ? 'Груз за лимитом!' 
                    : customizedBoxWeight === 0
                    ? 'Заполните коробку'
                    : 'Добавить этот бокс в корзину'
                  }
                </button>

              </div>

              {/* Informative eco note */}
              <div className="p-4 bg-transparent border border-brand-sand rounded-xl flex items-start gap-3">
                <ShieldCheck className="w-5 h-5 text-brand-sage flex-shrink-0 mt-0.5" />
                <div className="text-xs font-light text-brand-charcoal/70 leading-relaxed">
                  Мы гарантируем чистоту продуктов: если вы сомневаетесь в каком-либо ингредиенте, мы вернем вам его стоимость без лишних вопросов.
                </div>
              </div>

            </div>

          </div>

        </div>
      </section>

      {/* Sustainable micro infographics */}
      <section className="bg-brand-sage py-16 px-4 sm:px-8 text-brand-cream">
        <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-3 gap-12 text-center md:text-left relative">
          
          <div className="border-b md:border-b-0 md:border-r border-brand-cream/10 pb-8 md:pb-0 pr-0 md:pr-12">
            <span className="font-mono text-[10px] tracking-widest uppercase text-brand-sand block mb-2 block font-extrabold">сортировка семян</span>
            <h4 className="font-serif text-3xl font-light mb-3">Наши стандарты</h4>
            <p className="text-sm text-brand-cream/70 font-light leading-relaxed">
              Мы отбираем только натуральные сорта от селекционеров с безупречной историей. Ни у одного фермера нет разрешения на использование химикатов и гормональных кормов.
            </p>
          </div>

          <div className="border-b md:border-b-0 md:border-r border-brand-cream/10 pb-8 md:pb-0 pr-0 md:pr-12">
            <span className="font-mono text-[10px] tracking-widest uppercase text-brand-sand block mb-2 block font-extrabold">эко упаковка</span>
            <h4 className="font-serif text-3xl font-light mb-3">Сохранение лесов</h4>
            <p className="text-sm text-brand-cream/70 font-light leading-relaxed">
              Картонные ящики и деревянная древесина изготавливаются из сертифицированных восстанавливаемых лесов Сибири. Каждая сломанная коробка отправляется на макулатуру.
            </p>
          </div>

          <div>
            <span className="font-mono text-[10px] tracking-widest uppercase text-brand-sand block mb-2 block font-extrabold">бережная доставка</span>
            <h4 className="font-serif text-3xl font-light mb-3">CO₂ Нейтрально</h4>
            <p className="text-sm text-brand-cream/70 font-light leading-relaxed">
              Наш автопарк курьеров на 80% состоит из гибридов и электрических скутеров, снижая токсичные выбросы выхлопов СО₂ внутри жилых дворов города до абсолютного минимума.
            </p>
          </div>

        </div>
      </section>

      {/* Reviews and customer opinions */}
      <section id="reviews" className="py-20 px-4 sm:px-8 bg-brand-cream border-b border-brand-sand/40">
        <div className="max-w-7xl mx-auto">
          
          <div className="text-center max-w-2xl mx-auto mb-16">
            <span className="font-mono text-xs uppercase tracking-widest text-brand-sage-light block mb-3 font-bold">отзывы покупателей</span>
            <h2 className="font-serif text-3xl sm:text-5xl font-light tracking-tight text-neutral-900">Качество, которое хвалят</h2>
          </div>

          {/* Social Proof ratings widgets */}
          <div className="flex flex-wrap items-center justify-center gap-6 mb-12">
            <div className="bg-brand-beige border border-brand-sand px-6 py-4 rounded-xl flex items-center gap-4 shadow-sm">
              <div className="text-4xl font-serif font-bold text-brand-sage">4.95</div>
              <div>
                <div className="flex gap-1 text-amber-500">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="w-4 h-4 fill-amber-500" />
                  ))}
                </div>
                <span className="font-mono text-[10px] text-brand-charcoal/50 uppercase block mt-1">Оценка на основе 1,240 отзывов</span>
              </div>
            </div>

            {/* Filter tags */}
            <div className="flex gap-2">
              <button 
                id="filter-all"
                onClick={() => setRatingFilter('all')}
                className={`px-4 py-2 font-mono text-xs uppercase transition-all border ${
                  ratingFilter === 'all' 
                    ? 'bg-brand-sage text-brand-cream border-brand-sage' 
                    : 'bg-transparent border-brand-sand/60 text-brand-charcoal hover:bg-brand-beige'
                }`}
              >
                Все отзывы ({FEEDBACKS.length})
              </button>
              <button 
                id="filter-5"
                onClick={() => setRatingFilter(5)}
                className={`px-4 py-2 font-mono text-xs uppercase transition-all border flex items-center gap-1.5 ${
                  ratingFilter === 5 
                    ? 'bg-brand-sage text-brand-cream border-brand-sage' 
                    : 'bg-transparent border-brand-sand/60 text-brand-charcoal hover:bg-brand-beige'
                }`}
              >
                5 Звезд
                <Star className="w-3.5 h-3.5 fill-current" />
              </button>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {filteredFeedbacks.map((item) => (
              <div 
                key={item.id}
                className="p-8 bg-brand-beige/50 border border-brand-sand/60 rounded-xl relative flex flex-col justify-between"
              >
                <div>
                  <div className="flex justify-between items-start mb-6">
                    <div>
                      <h4 className="font-serif text-lg font-semibold text-neutral-900">{item.name}</h4>
                      <span className="font-mono text-[10px] text-brand-charcoal/50">{item.city}</span>
                    </div>
                    <div className="flex gap-0.5 text-amber-500">
                      {[...Array(item.rating)].map((_, idx) => (
                        <Star key={idx} className="w-3.5 h-3.5 fill-amber-500" />
                      ))}
                    </div>
                  </div>
                  <p className="text-xs sm:text-sm text-brand-charcoal/80 leading-relaxed font-light italic">
                    «{item.text}»
                  </p>
                </div>

                <div className="pt-6 mt-6 border-t border-brand-sand/30 flex items-center justify-between font-mono text-[10px]">
                  <span className="text-brand-sage uppercase font-bold">Проверенный Клиент</span>
                  <span className="text-brand-charcoal/40">{item.date}</span>
                </div>
              </div>
            ))}
          </div>

        </div>
      </section>

      {/* Structured FAQ Section */}
      <section id="faq" className="py-20 px-4 sm:px-8 bg-brand-beige border-b border-brand-sand/40">
        <div className="max-w-4xl mx-auto">
          
          <div className="text-center max-w-2xl mx-auto mb-16">
            <span className="font-mono text-xs uppercase tracking-widest text-brand-sage-light block mb-3 font-bold">информационный блок</span>
            <h2 className="font-serif text-3xl sm:text-5xl font-light tracking-tight text-neutral-900">Часто задаваемые вопросы</h2>
          </div>

          <div className="space-y-4">
            {[
              {
                q: "Откуда везутся все ваши овощи, зелень и молочные продукты?",
                a: "Мы работаем исключительно с сертифицированными семейными хозяйствами и индивидуальными хозяйствами из Калужской (сыры, овощи), Тульской (корнеплоды, зелень) и Московской областей. Все наши производители отказываются от пестицидов и используют принципы регенеративного земледелия."
              },
              {
                q: "В каком виде придет заказ и нужно ли возвращать коробку?",
                a: "Заказ доставляется в фирменных деревянных коробах. Мы бережем природу, поэтому короба являются многоразовыми. При следующей доставке вы просто отдаете пустой короб курьеру. Если вы делаете разовый заказ и не планируете больше заказывать, курьер переложит ваши продукты в экологичные бумажные крафт-пакеты прямо на месте."
              },
              {
                q: "Можно ли заказать регулярную подписку на продукты?",
                a: "Да, конечно! При оформлении заказа вы можете выбрать опцию «Регулярная подписка по вторникам». Это дает вам постоянную скидку 10% на все заказы, а коробка будет формироваться в автоматическом режиме с упором на самые свежие сезонные позиции."
              },
              {
                q: "Что делать, если плод приехал помятым или незрелым?",
                a: "У нас действует «Политика вежливого био-доверия». Если качество какого-то томата, шпината или ягоды вас не устроило, напишите нам или позвоните курьеру. Мы вернем вам 100% стоимости этого продукта на баланс без бюрократии, бумаг и требования высылать фотографии."
              }
            ].map((faq, index) => (
              <div 
                id={`faq-item-${index}`}
                key={index} 
                className="bg-brand-cream border border-brand-sand rounded-xl overflow-hidden shadow-sm"
              >
                
                <button
                  id={`faq-toggle-${index}`}
                  onClick={() => setOpenFaqIndex(openFaqIndex === index ? null : index)}
                  className="w-full text-left p-6 flex justify-between items-center outline-none focus:bg-brand-sage-ultra/10 transition-colors"
                >
                  <span className="font-serif text-sm sm:text-base font-semibold text-neutral-900 pr-4">
                    {faq.q}
                  </span>
                  {openFaqIndex === index ? (
                    <ChevronUp className="w-5 h-5 text-brand-sage flex-shrink-0" />
                  ) : (
                    <ChevronDown className="w-5 h-5 text-brand-charcoal/40 flex-shrink-0" />
                  )}
                </button>

                <AnimatePresence>
                  {openFaqIndex === index && (
                    <motion.div
                      initial={{ height: 0, opacity: 0 }}
                      animate={{ height: 'auto', opacity: 1 }}
                      exit={{ height: 0, opacity: 0 }}
                      transition={{ duration: 0.25 }}
                    >
                      <div className="px-6 pb-6 pt-1 text-xs sm:text-sm text-brand-charcoal/70 leading-relaxed border-t border-brand-sand/30">
                        {faq.a}
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>

              </div>
            ))}
          </div>

        </div>
      </section>

      {/* Sustainable Newsletter eco club */}
      <section className="py-20 px-4 sm:px-8 bg-brand-cream border-b border-brand-sand/40">
        <div className="max-w-4xl mx-auto bg-brand-sage text-brand-cream p-10 sm:p-14 relative overflow-hidden rounded-2xl shadow-xl">
          <div className="absolute right-[-40px] bottom-[-40px] w-64 h-64 bg-brand-sage-light/20 rounded-full blur-3xl pointer-events-none" />
          
          <div className="relative z-10 max-w-2xl text-center mx-auto space-y-6">
            <span className="font-mono text-xs uppercase tracking-widest text-brand-sand block font-bold">ЭКО-КЛУБ ORGANIC BOX</span>
            <h3 className="font-serif text-3xl sm:text-5xl font-light tracking-tight leading-[1.1]">
              Присоединяйтесь к осознанному рациону
            </h3>
            <p className="text-brand-cream/80 text-xs sm:text-sm max-w-lg mx-auto font-light leading-relaxed">
              Раз в две недели мы присылаем честный фермерский дайджест: информацию о сезонных новинках, секреты длительного хранения зелени и эксклюзивные скидки для эко-клуба. Никакого спама.
            </p>

            <form 
              id="newsletter-form"
              onSubmit={(e) => {
                e.preventDefault();
                alert('Поздравляем! Вы успешно присоединились к нашему эко-клубу. На вашу почту отправлен купон на бесплатную зелень 🥬');
                (e.target as any).reset();
              }}
              className="flex flex-col sm:flex-row gap-3 pt-4 w-full max-w-md mx-auto"
            >
              <input 
                id="newsletter-email"
                type="email" 
                placeholder="Ваш e-mail адрес" 
                required
                className="flex-1 bg-brand-cream/10 border border-brand-cream/30 text-brand-cream placeholder:text-brand-cream/50 px-4 py-3.5 focus:bg-brand-cream focus:text-brand-charcoal focus:placeholder:text-brand-charcoal/40 transition-all font-mono text-sm outline-none"
              />
              <button
                id="newsletter-submit"
                type="submit"
                className="bg-brand-sand hover:bg-brand-cream text-brand-charcoal font-semibold uppercase tracking-wider font-mono text-xs py-3.5 px-6 transition-colors"
              >
                Вступить в клуб
              </button>
            </form>

            <div className="text-[10px] font-mono text-brand-sand/60">
              Нажимая кнопку, вы подтверждаете согласие на бережную обработку персональных данных.
            </div>
          </div>
        </div>
      </section>

      {/* Sustainable Ethical Footer */}
      <footer className="bg-brand-beige py-16 px-4 sm:px-8 border-t border-brand-sand">
        <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-4 gap-12 font-mono text-xs">
          
          {/* Logo & details */}
          <div className="space-y-4">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-full bg-brand-sage flex items-center justify-center text-brand-cream">
                <Sprout className="w-4.5 h-4.5" />
              </div>
              <span className="font-serif text-md font-bold text-neutral-950">Organic Box</span>
            </div>
            <p className="text-brand-charcoal/60 leading-relaxed font-light uppercase text-[10px] tracking-wider">
              Сервис премиальной доставки фермерского локального урожая. Заряжая чистотой каждую тарелку.
            </p>
            <div className="text-[10px] text-brand-charcoal/40 pt-2">
              © 2026-2027 Organic Box.<br />
              Все права защищены по закону природы.
            </div>
          </div>

          {/* Quick links header */}
          <div className="space-y-4">
            <span className="font-bold text-brand-sage uppercase tracking-wider block border-b border-brand-sand pb-1">МЕНЮ СЕРВИСА</span>
            <ul className="space-y-2 font-light">
              <li><button onClick={() => scrollToId('benefits')} className="hover:text-brand-sage text-left transition-colors">Наша Философия</button></li>
              <li><button onClick={() => scrollToId('preconfigured')} className="hover:text-brand-sage text-left transition-colors">Готовые Сезонные Коробки</button></li>
              <li><button onClick={() => scrollToId('customizer')} className="hover:text-brand-sage text-left transition-colors">Интерактивный Конструктор</button></li>
              <li><button onClick={() => scrollToId('reviews')} className="hover:text-brand-sage text-left transition-colors">Отзывы Покупателей</button></li>
              <li><button onClick={() => scrollToId('faq')} className="hover:text-brand-sage text-left transition-colors">Вопросы и Ответы (FAQ)</button></li>
            </ul>
          </div>

          {/* Support and legal */}
          <div className="space-y-4">
            <span className="font-bold text-brand-sage uppercase tracking-wider block border-b border-brand-sand pb-1">ЭКО-ГАРАНТИИ</span>
            <ul className="space-y-2 font-light text-brand-charcoal/70">
              <li className="flex items-center gap-1.5">
                <Check className="w-3.5 h-3.5 text-brand-sage" />
                <span>Отказ от одноразового пластика</span>
              </li>
              <li className="flex items-center gap-1.5">
                <Check className="w-3.5 h-3.5 text-brand-sage" />
                <span>Бесплатный возврат при браке</span>
              </li>
              <li className="flex items-center gap-1.5">
                <Check className="w-3.5 h-3.5 text-brand-sage" />
                <span>Лабораторный тест на нитраты</span>
              </li>
              <li className="flex items-center gap-1.5">
                <Check className="w-3.5 h-3.5 text-brand-sage" />
                <span>Оплата за честный вес</span>
              </li>
            </ul>
          </div>

          {/* Support numbers / physical address */}
          <div className="space-y-4">
            <span className="font-bold text-brand-sage uppercase tracking-wider block border-b border-brand-sand pb-1">СВЯЗАТЬСЯ С НАМИ</span>
            <p className="text-brand-charcoal/80 leading-relaxed font-light">
              Служба деликатной заботы:<br />
              <strong className="text-neutral-950 font-bold block mt-1 hover:text-brand-sage transition-colors">8 (800) 555-32-26</strong>
              <span className="text-[10px] text-brand-charcoal/40 block">Каждый день с 07:00 до 22:00</span>
            </p>
            <p className="text-brand-charcoal/60 leading-relaxed font-light text-[10px]">
              Адрес хаба сборки:<br />
              Россия, Московская область, Истринский район, фермерский парк «Здоровье», Ангар 4Б.
            </p>
          </div>

        </div>
      </footer>

      {/* Slide-out Shopping Cart Side Drawer overlay */}
      <AnimatePresence>
        {isOpenCart && (
          <>
            {/* Dark backing overlay shadow */}
            <motion.div 
              id="cart-overlay"
              initial={{ opacity: 0 }}
              animate={{ opacity: 0.4 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsOpenCart(false)}
              className="fixed inset-0 bg-black z-50 transition-opacity"
            />

            {/* Sliding cabinet body */}
            <motion.div 
              id="cart-drawer"
              initial={{ x: '100%' }}
              animate={{ x: 0 }}
              exit={{ x: '100%' }}
              transition={{ type: 'spring', damping: 25, stiffness: 220 }}
              className="fixed top-0 right-0 bottom-0 w-full max-w-md bg-brand-cream z-50 shadow-2xl flex flex-col justify-between overflow-hidden"
            >
              
              {/* Header drawer controls */}
              <div className="p-6 border-b border-brand-sand flex items-center justify-between bg-brand-beige">
                <div className="flex items-center gap-2">
                  <ShoppingBag className="w-5 h-5 text-brand-sage" />
                  <h3 className="font-serif text-lg font-semibold text-neutral-900">Выбранные товары</h3>
                  <span className="bg-brand-sage-ultra text-brand-sage text-xs font-mono px-2 py-0.5 rounded-full font-bold">
                    {totalCartItemsCount}
                  </span>
                </div>
                
                <button 
                  id="close-cart-btn"
                  onClick={() => setIsOpenCart(false)}
                  className="w-8 h-8 rounded-full bg-brand-sand/30 hover:bg-brand-sand/70 transition flex items-center justify-center text-brand-charcoal"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              {/* Items scroll section */}
              <div className="flex-1 overflow-y-auto p-6 space-y-4">
                {cart.length === 0 ? (
                  <div className="text-center py-16 space-y-4">
                    <ShoppingBag className="w-12 h-12 text-brand-sand mx-auto opacity-75" />
                    <h4 className="font-serif text-lg text-brand-charcoal/60">Ваша корзина пока пуста</h4>
                    <p className="text-xs text-brand-charcoal/40 font-light max-w-xs mx-auto">
                      Вы можете добавить готовые сезонные коробки или собрать индивидуальный BioBox в нашем конструкторе.
                    </p>
                    <button
                      id="cart-go-customize"
                      onClick={() => {
                        setIsOpenCart(false);
                        scrollToId('customizer');
                      }}
                      className="inline-flex mt-2 items-center gap-1.5 px-4 py-2 fill-transparent font-mono text-[10px] uppercase tracking-wider bg-brand-sage text-brand-cream hover:bg-brand-charcoal"
                    >
                      перейти в конструктор
                    </button>
                  </div>
                ) : (
                  cart.map((item) => (
                    <div 
                      key={item.id} 
                      className="p-4 bg-brand-beige/40 border border-brand-sand/60 rounded-lg flex gap-4 relative"
                    >
                      {/* Product image */}
                      <div className="w-16 h-16 rounded overflow-hidden bg-brand-sand/20 flex-shrink-0">
                        <img 
                          src={item.image} 
                          alt={item.title} 
                          className="w-full h-full object-cover"
                          referrerPolicy="no-referrer"
                        />
                      </div>

                      {/* Title information details */}
                      <div className="flex-1 min-w-0 flex flex-col justify-between">
                        <div>
                          <div className="flex justify-between items-start">
                            <h4 className="font-serif text-sm font-bold text-neutral-900 truncate pr-4">{item.title}</h4>
                            <button
                              id={`remove-cart-${item.id}`}
                              onClick={() => removeCartItem(item.id)}
                              className="text-brand-charcoal/40 hover:text-rose-600 transition"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                          
                          {item.details && (
                            <p className="text-[10px] font-mono text-brand-charcoal/60 leading-tight mt-1 line-clamp-2">
                              {item.details}
                            </p>
                          )}
                        </div>

                        {/* Quantity & interactive increment counters */}
                        <div className="flex items-center justify-between mt-3 font-mono">
                          <span className="text-sm font-bold text-brand-sage">{item.price * item.quantity} ₽</span>
                          
                          <div className="flex items-center gap-1.5 bg-brand-cream border border-brand-sand/50 rounded-full py-0.5 px-1.5">
                            <button
                              id={`dec-cart-${item.id}`}
                              onClick={() => updateCartItemQty(item.id, -1)}
                              className="w-5 h-5 hover:bg-brand-beige rounded-full flex items-center justify-center text-brand-charcoal"
                            >
                              <Minus className="w-2.5 h-2.5" />
                            </button>
                            <span className="w-4 text-center text-xs font-bold">{item.quantity}</span>
                            <button
                              id={`inc-cart-${item.id}`}
                              onClick={() => updateCartItemQty(item.id, 1)}
                              className="w-5 h-5 hover:bg-brand-beige rounded-full flex items-center justify-center text-brand-charcoal"
                            >
                              <Plus className="w-2.5 h-2.5" />
                            </button>
                          </div>
                        </div>

                      </div>

                    </div>
                  ))
                )}
              </div>

              {/* Bottom drawer receipt total section */}
              {cart.length > 0 && (
                <div className="p-6 bg-brand-beige border-t border-brand-sand/80 space-y-4">
                  
                  {/* Promo-code input fields */}
                  <div className="p-3 bg-brand-cream border border-brand-sand rounded-xl space-y-2">
                    <span className="font-mono text-[9px] uppercase tracking-wider block text-brand-charcoal/50">Промокод на скидку:</span>
                    <div className="flex gap-2">
                      <input
                        id="promo-input"
                        type="text"
                        value={promoCodeInput}
                        onChange={(e) => setPromoCodeInput(e.target.value)}
                        placeholder="Например: BIO2026"
                        className="flex-1 bg-brand-beige border border-brand-sand px-3 py-1.5 text-xs font-mono uppercase"
                      />
                      <button
                        id="apply-promo-btn"
                        onClick={handleApplyPromo}
                        className="bg-brand-sage hover:bg-brand-charcoal text-brand-cream px-3 py-1.5 font-mono text-[10px] uppercase font-bold tracking-wider"
                      >
                        Применить
                      </button>
                    </div>
                    {promoError && <p className="text-[10px] font-mono text-rose-500">{promoError}</p>}
                    {promoSuccess && <p className="text-[10px] font-mono text-brand-sage font-bold">{promoSuccess}</p>}
                  </div>

                  {/* Calculations breakdown */}
                  <div className="space-y-1.5 font-mono text-xs">
                    <div className="flex justify-between text-brand-charcoal/60">
                      <span>Стоимость сборов:</span>
                      <span>{cartSubtotal} ₽</span>
                    </div>
                    {appliedDiscount && (
                      <div className="flex justify-between text-brand-accent">
                        <span>Скидка ({appliedDiscount}%):</span>
                        <span>-{discountAmount} ₽</span>
                      </div>
                    )}
                    <div className="flex justify-between text-brand-charcoal/60">
                      <span>Доставка эко-электрокаром:</span>
                      <span>{cartShippingCost === 0 ? 'БЕСПЛАТНО' : `${cartShippingCost} ₽`}</span>
                    </div>
                    {cartShippingCost > 0 && (
                      <div className="text-[10px] text-brand-charcoal/40 text-right">
                        Добавьте продуктов на {2500 - cartSubtotal} ₽ до бесплатной доставки!
                      </div>
                    )}
                  </div>

                  {/* Total line item */}
                  <div className="flex justify-between items-end border-t border-brand-sand pt-4 font-mono">
                    <span className="font-serif text-base text-neutral-900 uppercase">ОБЩАЯ СУММА:</span>
                    <strong className="text-2xl text-brand-sage font-extrabold">{cartTotal} ₽</strong>
                  </div>

                  {/* Checkout Button transition */}
                  <button
                    id="checkout-trigger"
                    onClick={() => {
                      setIsOpenCart(false);
                      setIsOpenCheckout(true);
                    }}
                    className="w-full text-center py-4 bg-brand-charcoal hover:bg-brand-sage text-brand-cream font-mono text-xs uppercase tracking-widest transition-all duration-300"
                  >
                    Перейти к оформлению заказа
                  </button>

                </div>
              )}

            </motion.div>
          </>
        )}
      </AnimatePresence>

      {/* Main Interactive Checkout Modal wrapper overlay */}
      <AnimatePresence>
        {isOpenCheckout && (
          <div className="fixed inset-0 z-50 overflow-y-auto bg-brand-charcoal/40 backdrop-blur-sm flex items-center justify-center p-4">
            
            <motion.div
              id="checkout-modal"
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-brand-cream border border-brand-sand max-w-2xl w-full p-6 sm:p-8 rounded-2xl shadow-2xl relative"
            >
              <button
                id="close-checkout"
                onClick={() => {
                  setIsOpenCheckout(false);
                  setCheckoutSuccessData(null);
                }}
                className="absolute top-4 right-4 w-8 h-8 rounded-full bg-brand-sand/30 hover:bg-brand-sand/70 transition flex items-center justify-center text-brand-charcoal"
              >
                <X className="w-4 h-4" />
              </button>

              {/* Order Success visual screen */}
              {checkoutSuccessData ? (
                <div className="text-center py-8 space-y-6">
                  <div className="w-16 h-16 rounded-full bg-brand-sage text-brand-cream flex items-center justify-center mx-auto mb-4">
                    <Check className="w-8 h-8" />
                  </div>
                  
                  <div className="space-y-2">
                    <span className="font-mono text-xs text-brand-sage-light uppercase tracking-wider block font-extrabold">Урожай зарезервирован!</span>
                    <h3 className="font-serif text-3xl font-light text-neutral-900">Заказ {checkoutSuccessData.orderId} успешно принят</h3>
                    <p className="text-xs sm:text-sm text-brand-charcoal/70 leading-relaxed font-light max-w-md mx-auto">
                      Вы ввели новые экологичные привычки. Наш фермер уже отправился в теплицу за молодой зеленью и спелыми черри.
                    </p>
                  </div>

                  {/* Summary card info */}
                  <div className="p-5 bg-brand-beige rounded-xl border border-brand-sand text-left font-mono text-xs space-y-3 max-w-md mx-auto">
                    <div className="flex justify-between">
                      <span className="text-brand-charcoal/50">АДРЕС КУРЬЕРА:</span>
                      <strong className="text-neutral-950 font-normal truncate max-w-[65%]">{checkoutSuccessData.address}</strong>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-brand-charcoal/50">ВРЕМЯ ПРИБЫТИЯ:</span>
                      <strong className="text-brand-sage">{checkoutSuccessData.deliveryTimeText}</strong>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-brand-charcoal/50">ИТОГОВАЯ СУММА:</span>
                      <strong className="text-brand-sage text-sm font-extrabold">{checkoutSuccessData.total} ₽ (Оплата картой курьеру)</strong>
                    </div>
                    <div className="text-[10px] border-t border-brand-sand/40 pt-2 text-brand-charcoal/40 text-center">
                      * Многоразовый короб курьер оставит вам или переложит заказ в крафт-пакеты.
                    </div>
                  </div>

                  {/* HIGH FIDELITY SIMULATION COMPONENT */}
                  <div className="border-t border-brand-sand/60 pt-6 max-w-md mx-auto space-y-4">
                    <div className="flex items-center gap-1 justify-center text-brand-sage font-serif font-bold text-sm">
                      <Clock className="w-4 h-4 animate-spin-slow" />
                      <span>Имитатор заказа на ферме вживую:</span>
                    </div>

                    {/* Step indicator pipeline */}
                    <div className="grid grid-cols-4 gap-2 relative">
                      {[
                        { icon: Sprout, label: "Сбор", desc: "Фермер срезает" },
                        { icon: ShieldCheck, label: "Контроль", desc: "Проверка нитратов" },
                        { icon: ShoppingBag, label: "Упаковка", desc: "Укладка в короб" },
                        { icon: Truck, label: "Доставка", desc: "Электрокар в пути" }
                      ].map((step, idx) => {
                        const StepIcon = step.icon;
                        const isCurrent = activeSimulatorStep === idx;
                        const isDone = activeSimulatorStep > idx;

                        return (
                          <div key={idx} className="flex flex-col items-center">
                            <div className={`w-10 h-10 rounded-full flex items-center justify-center transition-all ${
                              isDone ? 'bg-brand-sage text-brand-cream' : isCurrent ? 'bg-brand-accent text-white ring-4 ring-brand-accent/20 scale-105' : 'bg-neutral-200 text-neutral-400'
                            }`}>
                              <StepIcon className="w-5 h-5" />
                            </div>
                            <span className="text-[10px] font-mono font-bold mt-2 uppercase block leading-tight">{step.label}</span>
                            <span className="text-[8px] font-mono text-brand-charcoal/40 mt-0.5 leading-none block">{step.desc}</span>
                          </div>
                        );
                      })}
                    </div>

                    {/* Simulation logs ticker details */}
                    <div className="bg-brand-sage-ultra p-3 border border-brand-sage-light/20 rounded-md font-mono text-[10px] text-left text-brand-sage">
                      {activeSimulatorStep === 0 && "● [LOGS 15:08] Фермер Владимир из КФХ «Алешино» срезает бакинские огурцы и отбирает розовую редиску."}
                      {activeSimulatorStep === 1 && "● [LOGS 15:12] Огурцы и томаты успешно прошли замер тестером на нитраты. Показатель: 45 мг/кг (абсолютная норма: <150)."}
                      {activeSimulatorStep === 2 && "● [LOGS 15:15] Складываем деревянный короб. Добавляем охлаждающие эко-элементы для удержания температуры +4°С."}
                      {activeSimulatorStep === 3 && "● [LOGS 15:18] Курьер Иван загрузил короб в багажное отделение электроскутера и выехал в вашем направлении! Ожидайте звонка."}
                    </div>

                  </div>

                  <button
                    id="finish-order-btn"
                    onClick={() => {
                      setIsOpenCheckout(false);
                      setCheckoutSuccessData(null);
                    }}
                    className="w-full max-w-sm mt-4 px-8 py-3.5 bg-brand-charcoal hover:bg-brand-sage text-brand-cream font-mono text-xs uppercase tracking-wider"
                  >
                    Вернуться к сайту
                  </button>

                </div>
              ) : (
                // Checkout Form
                <form id="checkout-form" onSubmit={handleOrderSubmit} className="space-y-6">
                  
                  <div className="border-b border-brand-sand/60 pb-3">
                    <span className="font-mono text-xs uppercase tracking-wider text-brand-sage-light font-bold">ОФОРМЛЕНИЕ ДОСТАВКИ</span>
                    <h3 className="font-serif text-2xl font-light text-neutral-900 mt-1">Детали доставки фермерского заказа</h3>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 font-mono text-xs">
                    
                    {/* Customer name */}
                    <div className="space-y-1.5">
                      <label htmlFor="customer-name" className="text-brand-charcoal/60 uppercase block">ВАШЕ ИМЯ:</label>
                      <input
                        id="customer-name"
                        type="text"
                        required
                        placeholder="Как к вам обращаться"
                        value={customerName}
                        onChange={(e) => setCustomerName(e.target.value)}
                        className="w-full bg-brand-beige border border-brand-sand px-3 py-2.5 font-sans text-sm focus:bg-white focus:border-brand-sage outline-none"
                      />
                    </div>

                    {/* Customer phone number */}
                    <div className="space-y-1.5">
                      <label htmlFor="customer-phone" className="text-brand-charcoal/60 uppercase block">ТЕЛЕФОН СВЯЗИ:</label>
                      <input
                        id="customer-phone"
                        type="tel"
                        required
                        placeholder="+7 (999) 000-00-00"
                        value={customerPhone}
                        onChange={(e) => setCustomerPhone(e.target.value)}
                        className="w-full bg-brand-beige border border-brand-sand px-3 py-2.5 font-sans text-sm focus:bg-white focus:border-brand-sage outline-none"
                      />
                    </div>

                    {/* Address courier */}
                    <div className="sm:col-span-2 space-y-1.5">
                      <label htmlFor="customer-address" className="text-brand-charcoal/60 uppercase block">АДРЕС ДОСТАВКИ (МОСКВА И МО):</label>
                      <input
                        id="customer-address"
                        type="text"
                        required
                        placeholder="Улица, дом, квартира"
                        value={customerAddress}
                        onChange={(e) => setCustomerAddress(e.target.value)}
                        className="w-full bg-brand-beige border border-brand-sand px-3 py-2.5 font-sans text-sm focus:bg-white focus:border-brand-sage outline-none"
                      />
                    </div>

                    {/* Delivery Window Selector */}
                    <div className="sm:col-span-2 space-y-1.5">
                      <span className="text-brand-charcoal/60 uppercase block mb-1">ЖЕЛАЕМОЕ ВРЕМЯ ПОЛУЧЕНИЯ:</span>
                      <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                        {[
                          { id: 'today_evening', text: 'Сегодня вечером (18:00 - 19:30)' },
                          { id: 'tomorrow_morning', text: 'Завтра утром (09:00 - 11:00)' },
                          { id: 'tomorrow_day', text: 'Завтра днём (14:00 - 16:00)' }
                        ].map((time) => (
                          <button
                            id={`delivery-time-${time.id}`}
                            key={time.id}
                            type="button"
                            onClick={() => setDeliveryTime(time.id)}
                            className={`p-3 text-left border text-[11px] leading-snug transition-all uppercase font-mono ${
                              deliveryTime === time.id
                                ? 'bg-brand-sage-ultra border-brand-sage text-brand-sage font-bold'
                                : 'bg-transparent border-brand-sand hover:bg-brand-beige text-brand-charcoal'
                            }`}
                          >
                            {time.text}
                          </button>
                        ))}
                      </div>
                    </div>

                    {/* Notes text area */}
                    <div className="sm:col-span-2 space-y-1.5">
                      <label htmlFor="order-note" className="text-brand-charcoal/60 uppercase block">КОММЕНТАРИЙ ДЛЯ КУРЬЕРА (НЕОБЯЗАТЕЛЬНО):</label>
                      <textarea
                        id="order-note"
                        value={note}
                        onChange={(e) => setNote(e.target.value)}
                        placeholder="Код домофона, куда поставить ящик, или бесконтактная передача..."
                        rows={2}
                        className="w-full bg-brand-beige border border-brand-sand p-3 font-sans text-sm focus:bg-white focus:border-brand-sage outline-none resize-none"
                      />
                    </div>

                  </div>

                  {/* Summary items list before submit */}
                  <div className="p-4 bg-brand-beige rounded-xl border border-brand-sand font-mono text-[11px] text-brand-charcoal/70">
                    <span className="font-bold uppercase text-neutral-900 block mb-2">ВАШ ЗАКАЗ:</span>
                    <div className="space-y-1 max-h-32 overflow-y-auto">
                      {cart.map((item) => (
                        <div key={item.id} className="flex justify-between">
                          <span className="truncate max-w-[80%]">{item.title} x{item.quantity}</span>
                          <span>{item.price * item.quantity} ₽</span>
                        </div>
                      ))}
                    </div>
                    <div className="flex justify-between font-bold text-brand-sage text-sm border-t border-brand-sand/40 mt-3 pt-2">
                      <span className="font-serif font-semibold text-neutral-900 uppercase">ИСКУССТВЕННЫЙ ИТОГ С ДОСТАВКОЙ:</span>
                      <span>{cartTotal} ₽</span>
                    </div>
                  </div>

                  {/* Submit actions */}
                  <div className="flex flex-col sm:flex-row gap-3 pt-2">
                    <button
                      id="submit-order-btn"
                      type="submit"
                      disabled={isSubmittingOrder}
                      className="flex-1 text-center py-4 bg-brand-sage hover:bg-brand-charcoal text-brand-cream font-mono text-xs uppercase tracking-widest transition-colors cursor-pointer"
                    >
                      {isSubmittingOrder ? 'Отправляем заказ на ферму...' : 'Заказать свежий урожай'}
                    </button>
                    
                    <button
                      id="cancel-checkout-btn"
                      type="button"
                      onClick={() => setIsOpenCheckout(false)}
                      className="px-6 py-4 bg-transparent border border-brand-sand hover:bg-brand-beige text-brand-charcoal font-mono text-xs uppercase tracking-wider"
                    >
                      Назад к покупкам
                    </button>
                  </div>

                </form>
              )}

            </motion.div>
          </div>
        )}
      </AnimatePresence>

    </div>
  );
}
