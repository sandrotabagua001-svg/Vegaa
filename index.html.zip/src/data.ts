/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Product, BoxSizeDetails, PreconfiguredBox, Feedback } from './types';

// Let's import the generated high-quality images directly
export const HERO_IMAGE_PATH = '/src/assets/images/organic_hero_box_1779808167973.png';
const DETOX_IMAGE_PATH = '/src/assets/images/green_detox_box_1779808188256.png';
const FARM_IMAGE_PATH = '/src/assets/images/farm_morning_box_1779808208458.png';
const PICSUM_FALLBACK = 'https://picsum.photos/seed/organic-harvest/600/600';

export const PRODUCTS: Product[] = [
  // Vegetables
  {
    id: 'v1',
    name: 'Фермерские томаты черри',
    category: 'vegetables',
    price: 380,
    weight: 500,
    unit: '500 г',
    image: 'https://images.unsplash.com/photo-1546473533-f0b15ad46715?auto=format&fit=crop&w=300&q=80',
    calories: 90,
    origin: 'ферма «Заря», Тульская обл.'
  },
  {
    id: 'v2',
    name: 'Хрустящие огурцы бакинские',
    category: 'vegetables',
    price: 290,
    weight: 600,
    unit: '600 г',
    image: 'https://images.unsplash.com/photo-1449339091482-4412c3f0b17b?auto=format&fit=crop&w=300&q=80',
    calories: 72,
    origin: 'кооператив «Ока», Калужская обл.'
  },
  {
    id: 'v3',
    name: 'Молодая морковь на веточке',
    category: 'vegetables',
    price: 190,
    weight: 500,
    unit: '500 г',
    image: 'https://images.unsplash.com/photo-1598170845058-32b9d6a5da37?auto=format&fit=crop&w=300&q=80',
    calories: 165,
    origin: 'Эко-ферма «Велес», Тверская обл.'
  },
  {
    id: 'v4',
    name: 'Розовая редиска грунтовая',
    category: 'vegetables',
    price: 160,
    weight: 300,
    unit: '300 г',
    image: 'https://images.unsplash.com/photo-1592394533824-9440e5d68530?auto=format&fit=crop&w=300&q=80',
    calories: 48,
    origin: 'КФХ «Алешино», Московская обл.'
  },
  {
    id: 'v5',
    name: 'Тыква Баттернат мини',
    category: 'vegetables',
    price: 240,
    weight: 1000,
    unit: '1 шт (около 1 кг)',
    image: 'https://images.unsplash.com/photo-1570586437263-ab629fccc818?auto=format&fit=crop&w=300&q=80',
    calories: 450,
    origin: 'Органик-групп Самара'
  },

  // Greens
  {
    id: 'g1',
    name: 'Свежий мини-шпинат',
    category: 'greens',
    price: 220,
    weight: 150,
    unit: '150 г',
    image: 'https://images.unsplash.com/photo-1576045057995-568f588f82fb?auto=format&fit=crop&w=300&q=80',
    calories: 33,
    origin: 'Теплицы «Зеленый лист»'
  },
  {
    id: 'g2',
    name: 'Пряная руккола',
    category: 'greens',
    price: 240,
    weight: 125,
    unit: '125 г',
    image: 'https://images.unsplash.com/photo-1508747703725-719ae257c14a?auto=format&fit=crop&w=300&q=80',
    calories: 31,
    origin: 'Экоферма «Земляне»'
  },
  {
    id: 'g3',
    name: 'Ароматный зеленый базилик',
    category: 'greens',
    price: 180,
    weight: 70,
    unit: '70 г',
    image: 'https://images.unsplash.com/photo-1618228473300-9a5c57bbecb7?auto=format&fit=crop&w=300&q=80',
    calories: 16,
    origin: 'Био-кооператив Ярославль'
  },
  {
    id: 'g4',
    name: 'Хрустящий кудрявый кейл',
    category: 'greens',
    price: 310,
    weight: 200,
    unit: '200 г',
    image: 'https://images.unsplash.com/photo-1629450646452-f47c94515582?auto=format&fit=crop&w=300&q=80',
    calories: 100,
    origin: 'ферма «Никола Ленивец»'
  },

  // Fruits & Berries
  {
    id: 'f1',
    name: 'Лесная кустовая голубика',
    category: 'fruits',
    price: 490,
    weight: 250,
    unit: '250 г',
    image: 'https://images.unsplash.com/photo-1498557850523-fd3d118b962e?auto=format&fit=crop&w=300&q=80',
    calories: 140,
    origin: 'Дикоросы Карелии'
  },
  {
    id: 'f2',
    name: 'Сладкие яблоки Симиренко',
    category: 'fruits',
    price: 210,
    weight: 1000,
    unit: '1 кг',
    image: 'https://images.unsplash.com/photo-1560806887-1e4cd0b6cbd6?auto=format&fit=crop&w=300&q=80',
    calories: 520,
    origin: 'Сады Краснодара'
  },
  {
    id: 'f3',
    name: 'Груши сорт Конференс',
    category: 'fruits',
    price: 340,
    weight: 1000,
    unit: '1 кг',
    image: 'https://images.unsplash.com/photo-1514984879728-be0aff75a6e8?auto=format&fit=crop&w=300&q=80',
    calories: 570,
    origin: 'Сады Ставрополья'
  },
  {
    id: 'f4',
    name: 'Лесная земляника сладкая',
    category: 'fruits',
    price: 650,
    weight: 200,
    unit: '200 г',
    image: 'https://images.unsplash.com/photo-1518635017498-87f514b751ba?auto=format&fit=crop&w=300&q=80',
    calories: 64,
    origin: 'Лесные фермы Пскова'
  },

  // Dairy & Pantry
  {
    id: 'd1',
    name: 'Ремесленный ржаной цельнозерновой хлеб',
    category: 'dairy_pantry',
    price: 180,
    weight: 450,
    unit: '450 г (буханка)',
    image: 'https://images.unsplash.com/photo-1509440159596-0249088772ff?auto=format&fit=crop&w=300&q=80',
    calories: 1100,
    origin: 'Пекарня «Цельное зерно», Москва'
  },
  {
    id: 'd2',
    name: 'Домашние яйца (свободный выгул)',
    category: 'dairy_pantry',
    price: 250,
    weight: 10,
    unit: '10 шт',
    image: 'https://images.unsplash.com/photo-1506976785307-8732e854ad03?auto=format&fit=crop&w=300&q=80',
    calories: 780,
    origin: 'Фермерское подворье Тверь'
  },
  {
    id: 'd3',
    name: 'Луговой сырой мед диких пчел',
    category: 'dairy_pantry',
    price: 520,
    weight: 350,
    unit: '350 г (баночка)',
    image: 'https://images.unsplash.com/photo-1587049352846-4a222e784d38?auto=format&fit=crop&w=300&q=80',
    calories: 1050,
    origin: 'Семейная пасека, Алтай'
  },
  {
    id: 'd4',
    name: 'Молодой овечий сыр халуми',
    category: 'dairy_pantry',
    price: 490,
    weight: 250,
    unit: '250 г',
    image: 'https://images.unsplash.com/photo-1552763426-a704e743ffaa?auto=format&fit=crop&w=300&q=80',
    calories: 790,
    origin: 'Сыроварня «Ле Пти», Конаково'
  }
];

export const BOX_SIZES: BoxSizeDetails[] = [
  {
    size: 'S',
    name: 'Индивидуальный (Small)',
    price: 1490,
    maxWeight: 3.5,
    description: 'Идеально для недельного рациона одного человека. Вмещает до 3.5 кг свежей продукции.'
  },
  {
    size: 'M',
    name: 'Семейный (Standard)',
    price: 2490,
    maxWeight: 7.0,
    description: 'Оптимальный здоровый рацион для семейной пары. Вмещает до 7.0 кг свежей продукции.'
  },
  {
    size: 'L',
    name: 'Органик-Шеф (Premium)',
    price: 3690,
    maxWeight: 11.0,
    description: 'Максимальный набор для большой семьи или любителей готовить дома. Вмещает до 11.0 кг продукции.'
  }
];

export const PRECONFIGURED_BOXES: PreconfiguredBox[] = [
  {
    id: 'pb-detox',
    name: 'Био-Детокс и Свежесть',
    description: 'Специальный набор с преобладанием сочных зеленых овощей, хрустящих листьев шпината и яблок для поддержания легкости, очищения и энергии.',
    price: 1990,
    weight: '3.6 кг',
    image: DETOX_IMAGE_PATH,
    tags: ['Низкокалорийный', 'Витаминный заряд', 'До 2 человек'],
    items: ['Свежий мини-шпинат', 'Пряная руккола', 'Хрустящие огурцы бакинские', 'Сладкие яблоки Симиренко', 'Ароматный зеленый базилик', 'Кудрявый кейл']
  },
  {
    id: 'pb-morning',
    name: 'Утренний Фермерский Короб',
    description: 'Традиционные сытные продукты для идеального завтрака: свежевыпеченный ремесленный хлеб, натуральный сыр, домашние яйца и алтайский лесной мед.',
    price: 2690,
    weight: '2.5 кг',
    image: FARM_IMAGE_PATH,
    tags: ['Питательный', 'Традиционный фермерский', 'Завтраки'],
    items: ['Ремесленный ржаной цельнозерновой хлеб', 'Домашние яйца (свободный выгул)', 'Луговой сырой мед диких пчел', 'Молодой овечий сыр халуми']
  },
  {
    id: 'pb-garden',
    name: 'Полный Садовый Изобилие',
    description: 'Наш флагманский разноцветный сборник сочного фермерского урожая. Включает сладкие ягоды, твердые спелые овощи и пряную свежую зелень.',
    price: 3890,
    weight: '6.8 кг',
    image: 'https://images.unsplash.com/photo-1542838132-92c53300491e?auto=format&fit=crop&w=600&q=80',
    tags: ['Бестселлер', 'Вся палитра фермы', 'Семейный'],
    items: ['Фермерские томаты черри', 'Хрустящие огурцы бакинские', 'Молодая морковь на веточке', 'Тыква Баттернат мини', 'Лесная кустовая голубика', 'Салат кейл', 'Базилик']
  }
];

export const FEEDBACKS: Feedback[] = [
  {
    id: 'fb1',
    name: 'Елена Рудковская',
    city: 'Москва',
    rating: 5,
    text: 'Огурцы просто невероятные — пахнут настоящей землей, как в детстве на даче у бабушки! Доставка в деревянном коробе это отдельная эстетика, ничего не помялось. Буду заказывать еженедельно.',
    date: '24 мая 2026'
  },
  {
    id: 'fb2',
    name: 'Михаил Котов',
    city: 'Зеленоград',
    rating: 5,
    text: 'Очень удобный конструктор бокса. У меня аллергия на цитрусовые и рукколу, поэтому готовые смеси из супермаркета не подходят. Тут я сам набрал томаты, шпинат и обалденный овечий сыр. Качество 10 из 10.',
    date: '18 мая 2026'
  },
  {
    id: 'fb3',
    name: 'Анна Савельева',
    city: 'Санкт-Петербург',
    rating: 5,
    text: 'Кустовая земляника и голубика сладкие, чистые, ягодка к ягодке! Курьер привез коробку бесконтактным способом, вежливый и в биоразлагаемой форме. Очень нравится политика экологичности бренда.',
    date: '10 мая 2026'
  }
];
